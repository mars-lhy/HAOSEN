#include "xparameters.h"
#include <xbasic_types.h>
#include <xio.h>

/*Register CLASS*/
#define USER			(0x00000000)
#define RESET_MIR		(0x00000100)
#define IPIF_INT		(0x00000200)

/*Register Name*/
#define USER0			(0x00000000)
#define USER1			(0x00000004)
#define RESET			(0x00000000)
#define MIR				(0x00000000)
#define DISR			(0x00000000)
#define DIPR			(0x00000004)
#define DIER			(0x00000008)
#define DIIR			(0x00000018)
#define DGIER			(0x0000001C)
#define IPISR			(0x00000020)
#define IPIER			(0x00000028)

#define SEC1			(0xFD050F7F)	
#define MS500			(0xFE8287BF)
#define MS250			(0xFF4143DF)
#define INT0	(0x00000001)
#define INT1	(0x00000002)
#define Busy	(0x80000000)
#define INIT_DATA0 (0x80000C33)
#define INIT_DATA1 (0x40000C28)
#define INIT_DATA2 (0x20000C0C)
#define INIT_DATA3 (0x10000C01)
#define INIT_DATA4 (0x80000C06)
#define WriteREG(BaseAddress,RegClass,RegName,Data) XIo_Out32((BaseAddress)+(RegClass)+(RegName),(Xuint32)(Data))
#define ReadREG(BaseAddress,RegClass,RegName) XIo_In32((BaseAddress)+(RegClass)+(RegName))

 Xuint32 FLAG,TIMER1,TIMER2,TIMER3,LED_DATA;
const char Xilinx[16]={0x07,0x0c,0x06,0x03,0x06,0x0c,0x07,0x00,0x0c,0x18,0x00,0x00,0x00,0x18,0x0c,0x00};
 Delay10ms()
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001000);
 do
 {
 FLAG = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1);
 xil_printf("   ---Delay 10 ms : 0x%08x \n\r",FLAG );
 }
 while ( FLAG & Busy );
 }

 GIE_ENABLE()
 {
 /*Enable DGIER*/
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,DGIER,0X80000000);
 xil_printf("   ---DGIE ENABLED ! \n\r");

 }

 GIE_DISABLE()
 {
 /*Enable DGIER*/
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,DGIER,0X00000000);
 }

 INT0_ENABLE()
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,IPIER,0x00000001);
 xil_printf("   ---TIMER0 INTERRUPT ENABLED ! \n\r");

 }
 
 INT1_ENABLE()
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,IPIER,0x00000002);
 xil_printf("   ---LCD READY INTERRUPT ENABLED ! \n\r");

 }
 
 INT_ENABLE()
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,IPIER,0x00000003);
 }
 
 INT_DISABLE()
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,IPIER,0x00000000);
 }
 
 SetTimer0(T)
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0,T);
 }
 
 DisplayClear ()
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x00000C01);
 do
 {
 FLAG = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1);
 xil_printf("   ---Display Clear : 0x%08x \n\r",FLAG );
 }
 while ( FLAG & Busy );
 }
 
 ReturnHome ()
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x00000C02);
 do
 {
 FLAG = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1);
 xil_printf("   ---Return Home : 0x%08x \n\r",FLAG );
 }
 while ( FLAG & Busy );
 }
 
 EntryMode (I_d,S)
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x00000C04+(I_d<<1)+S);
 do
 {
 FLAG = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1);
 xil_printf("   ---EntryMode : 0x%08x \n\r",FLAG );
 }
 while ( FLAG & Busy );
 }
 
 DisplayOnOff(D,C,B)
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x00000C08+(D<<2)+(C<<1)+B);
 do
 {
 FLAG = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1);
 xil_printf("   ---DisplayOnOff : 0x%08x \n\r",FLAG );
 }
 while ( FLAG & Busy );
 }


 CursorDisplayShift(S_c,R_l)
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x00000C10+(S_c<<3)+(R_l<<2));
 do
 {
 FLAG = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1);
 xil_printf("   ---CursorDisplayShift : 0x%08x \n\r",FLAG );
 }
 while ( FLAG & Busy );
 }
 
 
 FunctionSet(MODE,DL,N,F)
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x00000420+(MODE<<11)+(DL<<4)+(N<<3)+(F<<2));
 do
 {
 FLAG = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1);
 xil_printf("   ---FunctionSet : 0x%08x \n\r",FLAG );
 }
 while ( FLAG & Busy ); 
 }

 SetCGRAM(Addr)
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x00000C40+(Addr & 0x0000003F));
 do
 {
 FLAG = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1);
 xil_printf("   ---Set CGRAM Address : 0x%08x \n\r",FLAG );
 }
 while ( FLAG & Busy ); 

 }
 
 SetDDRAM(Addr)
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x00000C80+(Addr & 0x0000007F));
 do
 {
 FLAG = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1);
 xil_printf("   ---Set DDRAM Address : 0x%08x \n\r",FLAG );
 }
 while ( FLAG & Busy ); 
 }
 
 Xuint32 CheckBusy()
 {
 FLAG = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1);
 xil_printf("   ---Check Busy : 0x%08x \n\r",FLAG );
 FLAG = FLAG & 0x80000000; 
 return FLAG; 
 }
 
 WriteData(Data)
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x00000E00+Data);
 do
 {
 FLAG = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1);
 xil_printf("   ---Write Data : 0x%08x \n\r",FLAG );
 }
 while ( FLAG & Busy ); 
 
 }

 INIT_LCD ()
 {
 FunctionSet(0,1,1,0);/*MODE=0,DL=1,N=1,F=0*/
 Delay10ms();
 FunctionSet(0,1,1,0);/*MODE=0,DL=1,N=1,F=0*/
 Delay10ms();
 FunctionSet(0,1,1,0);/*MODE=0,DL=1,N=1,F=0*/
 Delay10ms();
 FunctionSet(0,0,1,0);/*MODE=0,DL=0,N=1,F=0*/
 Delay10ms();
 FunctionSet(1,0,1,0);/*MODE=1,DL=0,N=1,F=0*/
 DisplayOnOff(1,0,0);/*D=1,C=0,B=0*/
 DisplayClear();
 EntryMode (1,0);
 Delay10ms();
 Delay10ms();
 }

 SetCursor(y,x)
 {
 int temp;
 x=(x<=1)?1:((x>40)?40:x);
 y=(y<=1)?1:2;
 y=(y==1)?0:64;
 x--;
 y=y+x;
 SetDDRAM(y);
 }
 
 PutChar(char CH)
 {
 WriteData(CH);
 }
 
 WriteString(char*STR)
 {
 int i=0;
 while (STR[i]!='\0')
 {
 PutChar(STR[i]);
 i++;
 }
 }
 
 Xdefine()
 {
 int i;
 SetCGRAM(0x00);
 for(i=0;i<=16;i++)
 {
 WriteData(Xilinx[i]);
 
 }
 }
 
 WriteX()
 {
 WriteData(0);
 WriteData(1);
 }


Xilinx_()
{
int m;
m=1;
while (m<35)
{
SetCursor(1,m);
WriteX();
WriteString("ilinx");
m=m+10;
}
m=4;

while(m<35)
{
SetCursor(2,m);
WriteX();
WriteString("ilinx");
m=m+10;
TIMER1=0;
}
}
LED()
{
WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,LED_DATA<<23);
 
}


void INT_HANDLER(void *baseaddress_p)
{

  Xuint32 ReadBUF;
  
  
  ReadBUF = ReadREG(baseaddress_p,IPIF_INT,IPISR);
  if ((ReadBUF & INT0)!=0)
	{
	WriteREG(baseaddress_p,IPIF_INT,IPISR,INT0);
   xil_printf("   ---Processing INT0---\n\r");
 	
	}
 else if ((ReadBUF & INT1)!=0)
	{
	WriteREG(baseaddress_p,IPIF_INT,IPISR,02);
	xil_printf("   ---Processing INT1---\n\r");
	}
TIMER1++;
TIMER2++;
TIMER3++; 
LED_DATA++;
 xil_printf("---Timer1: 0x%08x \n\r", TIMER1);
 xil_printf("---Timer2: 0x%08x \n\r", TIMER2);
 xil_printf("---Timer3: 0x%08x \n\r", TIMER3);
/*   WriteREG(baseaddress_p,USER,USER1,FLAG<<24);*/
}


/* USER0*/
/*0 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 20 1 2 3 4 5 6 7 8 9 30 1*/
/*L E |                    2---31   30bit Timer                    |*/
/*o n |                                                            |*/
/*a a |                                                            |*/
/*d b |                                                            |*/
/*  l |                                                            |*/
/*  e |                                                            |*/

/* USER1*/
/*0 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 20 1 2 3 4 5 6 7 8 9 30 1*/
/*|  0--7  led  |                        | A  L R R |              |*/
/*|  set timer2 when bit19=1 else const  | u  o S W |              |*/
/*|               50us/1800us            | t  a     |              |*/
/*|                                      | o  d     |              |*/
/*|                                      |(1)       |   LCD DATA   |*/

 main()
{
 int i,j,k,m,n;
Xuint32 ReadBUF;
/*RESET OPB*/
/*WriteREG(XPAR_S3ESK_LCD_0_BASEADDR,RESET_MIR,RESET,0x0000000A);*/

/*Set timer0---INTERRUPT EVERY 250ms */
SetTimer0(MS250);

ReadBUF = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("--- User Register0: 0x%08x \n\r",ReadBUF );

/*Enable Interrupt*/
xil_printf("---User Register1: 0x%08x \n\r",ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1) );

microblaze_enable_interrupts();
GIE_ENABLE();
INT0_ENABLE();
INIT_LCD();
Xdefine();

/*-----------Test1------------*/
Xilinx_();
for (j=1;j<=20;j++)
{
while (TIMER1<=1);
TIMER1=0;
CursorDisplayShift(1,0);
LED();
}

/*-----------Test2------------*/

DisplayClear();

TIMER1=0;
SetCursor(1,4);
WriteString("Welcome To use MicroBlaze LCD Driver");
SetCursor(2,15);
WriteString("for Spartan3E Starter kit");
for (i=1;i<3;i++)
{
for (j=1;j<27;j++)
{
while (TIMER1<=1);
TIMER1=0;
CursorDisplayShift(1,0);
LED();

}

ReturnHome();
}

/*-----------Test3------------*/
DisplayClear();
TIMER1=0;
TIMER2=0;
TIMER3=0;
j=0x20;
k=0xA0;
m=16;
SetCursor(1,m);
for (i=m;i<=40;i++)
 {
 j++;
 WriteData(j);
 }
 SetCursor(2,m);
for (i=m;i<=40;i++)
 {
 k++;
 WriteData(k);
 }
 i=0;
 m=0;
 while(i<94)
 {
 
 if (TIMER2>=2) /*0.5s*/
	{
 CursorDisplayShift(1,0);
	i++;
	j++;
	k++;
	m++;
	SetCursor(1,m);
 WriteData(j);
	SetCursor(2,m);
 WriteData(k);
	if (m>=40){m=0;}
	TIMER2=0;
 	}
}
TIMER1=0;
while (TIMER1<10);
ReturnHome();

DisplayClear();
Xilinx_();

while(1)
{
while (TIMER1<=1);
TIMER1=0;
CursorDisplayShift(1,0);
LED();
/*ReturnHome();*/
}

}/*main*/
