#include "xparameters.h"
#include <xbasic_types.h>
#include <xio.h>

/*Register CLASS*/
#define USER			(0x00000000)
#define RESET_MIR		(0x00000100)
#define IPIF_INT		(0x00000200)

/*Register Name*/
#define USER0			(0x00000000)
#define USER1			(0x00000004)
#define RESET			(0x00000000)
#define MIR				(0x00000000)
#define DISR			(0x00000000)
#define DIPR			(0x00000004)
#define DIER			(0x00000008)
#define DIIR			(0x00000018)
#define DGIER			(0x0000001C)
#define IPISR			(0x00000020)
#define IPIER			(0x00000028)

#define SEC1			(0xFD050F7F)	
#define MS500			(0xFE8287BF)
#define MS250			(0xFF4143DF)
#define ttt		(0xC0000000)
#define INT0	(0x00000001)
#define INT1	(0x00000002)
#define BUSY	(0x80000000)
#define INIT_DATA0 (0x80000C33)
#define INIT_DATA1 (0x40000C28)
#define INIT_DATA2 (0x20000C0C)
#define INIT_DATA3 (0x10000C01)
#define INIT_DATA4 (0x80000C06)
#define WriteREG(BaseAddress,RegClass,RegName,Data) XIo_Out32((BaseAddress)+(RegClass)+(RegName),(Xuint32)(Data))
#define ReadREG(BaseAddress,RegClass,RegName) XIo_In32((BaseAddress)+(RegClass)+(RegName))

Xuint32 *FLAG,INT_BUF,FLAG1;
 void Delay0()
 {
 int i;
 for (i=0;i<5000;i++);
 }

 void GIE_ENABLE()
 {
 /*Enable DGIER*/
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,DGIER,0X80000000);
 xil_printf("   ---DGIE ENABLED ! \n\r");

 }

 void GIE_DISABLE()
 {
 /*Enable DGIER*/
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,DGIER,0X00000000);
 }

 void INT0_ENABLE()
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,IPIER,0x00000001);
 xil_printf("   ---TIMER0 INTERRUPT ENABLED ! \n\r");

 }
 
 void INT1_ENABLE()
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,IPIER,0x00000002);
 xil_printf("   ---LCD READY INTERRUPT ENABLED ! \n\r");

 }
 void INT_ENABLE()
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,IPIER,0x00000003);
 }
 void INT1_DISABLE()
 {
 INT_BUF = INT_BUF & 0xFFFFFFFD;
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,IPIF_INT,IPIER,INT_BUF);
 }
 
 void SET_TIMER0(T)
 {
 WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0,T);
 }
 
 void INIT_LCD ()
 {
Xuint32 FLAG2;

WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001430);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE0) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );
WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001430);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE0) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );
WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001430);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE0) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );

WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001420);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE1) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );

WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001420);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE2) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );

WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001480);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE3) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );
WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001400);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE4) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );

WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001460);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE5) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );

WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001400);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE6) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );
WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x800014C0);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE6) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );

WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001400);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE6) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );
WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001410);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE6) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );





WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x800014C0);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE7) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );
WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0x80001410);
do
{
FLAG2 = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   ---Busy FLAG(CODE6) : 0x%08x \n\r",FLAG2 );
}
while ( FLAG2 & 0x80000000 );

 }
 
void INT_HANDLER(void *baseaddress_p)
{
  Xuint32 ReadBUF;
  ReadBUF = ReadREG(baseaddress_p,IPIF_INT,IPISR);
  if ((ReadBUF & INT0)!=0)
	{
	WriteREG(baseaddress_p,IPIF_INT,IPISR,INT0);
   xil_printf("   ---Processing INT0---\n\r");
WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,INIT_DATA3);
 	
	}
 else if ((ReadBUF & INT1)!=0)
	{
	WriteREG(baseaddress_p,IPIF_INT,IPISR,03);
	xil_printf("   ---Processing INT1---\n\r");
	*FLAG = 0;
	}
 
 xil_printf("   - IP (user logic) interrupt status : 0x%08x \n\r", ReadBUF);
/*   WriteREG(baseaddress_p,USER,USER1,FLAG<<24);*/

}
/* USER0*/
/*0 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 20 1 2 3 4 5 6 7 8 9 30 1*/
/*L E |                    2---31   30bit Timer                    |*/
/*o n |                                                            |*/
/*a a |                                                            |*/
/*d b |                                                            |*/
/*  l |                                                            |*/
/*  e |                                                            |*/

/* USER1*/
/*0 1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 20 1 2 3 4 5 6 7 8 9 30 1*/
/*|  0--7  led  |                        | A  L R R |              |*/
/*|  set timer2 when bit19=1 else const  | u  o S W |              |*/
/*|               40us/1600us            | t  a     |              |*/
/*|                                      | o  d     |              |*/
/*|                                      |(1)       |   LCD DATA   |*/

int main()
{
   Xuint32 ReadBUF;
/*RESET OPB*/
/*WriteREG(XPAR_INT_TEST_0_BASEADDR,reset_mir_offset,RESET,0x0000000A)*/

/*Set timer0 */
SET_TIMER0(SEC1);

ReadBUF = ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER0);
xil_printf("   - IP (user logic) User0 : 0x%08x \n\r",ReadBUF );
/*Set timer1*/
/*Enable Interrupt*/
xil_printf("   - IP (user logic) UserREG1 : 0x%08x \n\r",ReadREG(XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1) );

microblaze_enable_interrupts();
GIE_ENABLE();
INT1_ENABLE();
INIT_LCD();
/*WriteREG (XPAR_S3ESK_LCD_0_BASEADDR,USER,USER1,0xff000c33);
*/
while(1);
return 0;
}
