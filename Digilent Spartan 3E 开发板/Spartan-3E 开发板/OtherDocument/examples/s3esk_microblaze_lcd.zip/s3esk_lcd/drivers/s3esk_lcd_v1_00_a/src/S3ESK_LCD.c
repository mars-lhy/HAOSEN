//////////////////////////////////////////////////////////////////////////////
// Filename:          E:\MicroBlaze\s3esk_lcd/drivers/S3ESK_LCD_v1_00_a/src/S3ESK_LCD.c
// Version:           1.00.a
// Description:       S3ESK_LCD Driver Source File
// Date:              Tue Jun 27 06:58:14 2006 (by Create and Import Peripheral Wizard)
//////////////////////////////////////////////////////////////////////////////


/***************************** Include Files *******************************/

#include "S3ESK_LCD.h"

/************************** Function Definitions ***************************/

/**
 *
 * Enable all possible interrupts from S3ESK_LCD device.
 *
 * @param   baseaddr_p is the base address of the S3ESK_LCD device.
 *
 * @return  None.
 *
 * @note    None.
 *
 */
void S3ESK_LCD_EnableInterrupt(void * baseaddr_p)
{
  Xuint32 baseaddr;
  baseaddr = (Xuint32) baseaddr_p;

  /*
   * Enable all interrupt source from user logic.
   */
  S3ESK_LCD_mWriteReg(baseaddr, S3ESK_LCD_INTR_IER_OFFSET, 0x00000002);

  /*
   * Enable all possible interrupt sources from device.
   */
  S3ESK_LCD_mWriteReg(baseaddr, S3ESK_LCD_INTR_DIER_OFFSET,
    INTR_TERR_MASK
    | INTR_DPTO_MASK
    | INTR_IPIR_MASK
    );

  /*
   * Set global interrupt enable.
   */
  S3ESK_LCD_mWriteReg(baseaddr, S3ESK_LCD_INTR_DGIER_OFFSET, INTR_GIE_MASK);
}

/**
 *
 * Example interrupt controller handler for S3ESK_LCD device.
 * This is to show example of how to toggle write back ISR to clear interrupts.
 *
 * @param   baseaddr_p is the base address of the S3ESK_LCD device.
 *
 * @return  None.
 *
 * @note    None.
 *
 */
void S3ESK_LCD_Intr_DefaultHandler(void * baseaddr_p)
{
  Xuint32 baseaddr;
  Xuint32 IntrStatus;

  baseaddr = (Xuint32) baseaddr_p;

  /*
   * Get status from IP Interrupt Status Register.
   */
  IntrStatus = S3ESK_LCD_mReadReg(baseaddr, S3ESK_LCD_INTR_ISR_OFFSET);

  xil_printf("IP Interrupt! Status register (ISR) value : 0x%08x \n\r", IntrStatus);

  /*
   * Clear IP interrupts by toggle write back to IP ISR register.
   */
  S3ESK_LCD_mWriteReg(baseaddr, S3ESK_LCD_INTR_ISR_OFFSET, IntrStatus);
}

