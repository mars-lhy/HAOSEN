//////////////////////////////////////////////////////////////////////////////
// Filename:          E:\MicroBlaze\s3esk_lcd/drivers/S3ESK_LCD_v1_00_a/src/S3ESK_LCD.h
// Version:           1.00.a
// Description:       S3ESK_LCD Driver Header File
// Date:              Tue Jun 27 06:58:14 2006 (by Create and Import Peripheral Wizard)
//////////////////////////////////////////////////////////////////////////////

#ifndef S3ESK_LCD_H
#define S3ESK_LCD_H

/***************************** Include Files *******************************/

#include "xbasic_types.h"
#include "xstatus.h"
#include "xio.h"

/************************** Constant Definitions ***************************/


/**
 * User Logic Slave Space Offsets
 * -- SLAVE_REG0 : user logic slave module register 0
 * -- SLAVE_REG1 : user logic slave module register 1
 */
#define S3ESK_LCD_USER_SLAVE_SPACE_OFFSET (0x00000000)
#define S3ESK_LCD_SLAVE_REG0_OFFSET (S3ESK_LCD_USER_SLAVE_SPACE_OFFSET + 0x00000000)
#define S3ESK_LCD_SLAVE_REG1_OFFSET (S3ESK_LCD_USER_SLAVE_SPACE_OFFSET + 0x00000004)

/**
 * IPIF Reset/Mir Space Register Offsets
 * -- RST : software reset register
 * -- MIR : module identification register
 */
#define S3ESK_LCD_IPIF_RST_SPACE_OFFSET (0x00000100)
#define S3ESK_LCD_RST_OFFSET (S3ESK_LCD_IPIF_RST_SPACE_OFFSET + 0x00000000)
#define S3ESK_LCD_MIR_OFFSET (S3ESK_LCD_IPIF_RST_SPACE_OFFSET + 0x00000000)

/**
 * IPIF Reset/Mir Masks
 * -- IPIF_MAVN_MASK   : module major version number
 * -- IPIF_MIVN_MASK   : module minor version number
 * -- IPIF_MIVL_MASK   : module minor version letter
 * -- IPIF_BID_MASK    : module block id
 * -- IPIF_BTP_MASK    : module block type
 * -- IPIF_RESET       : software reset
 */
#define IPIF_MAVN_MASK (0xF0000000UL)
#define IPIF_MIVN_MASK (0x0FE00000UL)
#define IPIF_MIVL_MASK (0x001F0000UL)
#define IPIF_BID_MASK (0x0000FF00UL)
#define IPIF_BTP_MASK (0x000000FFUL)
#define IPIF_RESET (0x0000000A)

/**
 * IPIF Interrupt Controller Space Offsets
 * -- INTR_DISR  : device (ipif) interrupt status register
 * -- INTR_DIPR  : device (ipif) interrupt pending register
 * -- INTR_DIER  : device (ipif) interrupt enable register
 * -- INTR_DIIR  : device (ipif) interrupt id (priority encoder) register
 * -- INTR_DGIER : device (ipif) global interrupt enable register
 * -- INTR_ISR   : ip (user logic) interrupt status register
 * -- INTR_IER   : ip (user logic) interrupt enable register
 */
#define S3ESK_LCD_IPIF_INTR_SPACE_OFFSET (0x00000200)
#define S3ESK_LCD_INTR_DISR_OFFSET (S3ESK_LCD_IPIF_INTR_SPACE_OFFSET + 0x00000000)
#define S3ESK_LCD_INTR_DIPR_OFFSET (S3ESK_LCD_IPIF_INTR_SPACE_OFFSET + 0x00000004)
#define S3ESK_LCD_INTR_DIER_OFFSET (S3ESK_LCD_IPIF_INTR_SPACE_OFFSET + 0x00000008)
#define S3ESK_LCD_INTR_DIIR_OFFSET (S3ESK_LCD_IPIF_INTR_SPACE_OFFSET + 0x00000018)
#define S3ESK_LCD_INTR_DGIER_OFFSET (S3ESK_LCD_IPIF_INTR_SPACE_OFFSET + 0x0000001C)
#define S3ESK_LCD_INTR_ISR_OFFSET (S3ESK_LCD_IPIF_INTR_SPACE_OFFSET + 0x00000020)
#define S3ESK_LCD_INTR_IER_OFFSET (S3ESK_LCD_IPIF_INTR_SPACE_OFFSET + 0x00000028)

/**
 * IPIF Interrupt Controller Masks
 * -- INTR_TERR_MASK : transaction error
 * -- INTR_DPTO_MASK : data phase time-out
 * -- INTR_IPIR_MASK : ip interrupt requeset
 * -- INTR_DMA0_MASK : dma channel 0 interrupt request
 * -- INTR_DMA1_MASK : dma channel 1 interrupt request
 * -- INTR_RFDL_MASK : read packet fifo deadlock interrupt request
 * -- INTR_WFDL_MASK : write packet fifo deadlock interrupt request
 * -- INTR_IID_MASK  : interrupt id
 * -- INTR_GIE_MASK  : global interrupt enable
 * -- INTR_NOPEND    : the DIPR has no pending interrupts
 */
#define INTR_TERR_MASK (0x00000001UL)
#define INTR_DPTO_MASK (0x00000002UL)
#define INTR_IPIR_MASK (0x00000004UL)
#define INTR_DMA0_MASK (0x00000008UL)
#define INTR_DMA1_MASK (0x00000010UL)
#define INTR_RFDL_MASK (0x00000020UL)
#define INTR_WFDL_MASK (0x00000040UL)
#define INTR_IID_MASK (0x000000FFUL)
#define INTR_GIE_MASK (0x80000000UL)
#define INTR_NOPEND (0x80)

/***************** Macros (Inline Functions) Definitions *******************/

/**
 *
 * Write a value to a S3ESK_LCD register. A 32 bit write is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is written.
 *
 * @param   BaseAddress is the base address of the S3ESK_LCD device.
 * @param   RegOffset is the register offset from the base to write to.
 * @param   Data is the data written to the register.
 *
 * @return  None.
 *
 * @note    None.
 *
 * C-style signature:
 * 	void S3ESK_LCD_mWriteReg(Xuint32 BaseAddress, unsigned RegOffset, Xuint32 Data)
 *
 */
#define S3ESK_LCD_mWriteReg(BaseAddress, RegOffset, Data) \
 	XIo_Out32((BaseAddress) + (RegOffset), (Xuint32)(Data))

/**
 *
 * Read a value from a S3ESK_LCD register. A 32 bit read is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is read from the register. The most significant data
 * will be read as 0.
 *
 * @param   BaseAddress is the base address of the S3ESK_LCD device.
 * @param   RegOffset is the register offset from the base to write to.
 *
 * @return  Data is the data from the register.
 *
 * @note    None.
 *
 * C-style signature:
 * 	Xuint32 S3ESK_LCD_mReadReg(Xuint32 BaseAddress, unsigned RegOffset)
 *
 */
#define S3ESK_LCD_mReadReg(BaseAddress, RegOffset) \
 	XIo_In32((BaseAddress) + (RegOffset))


/**
 *
 * Write/Read value to/from S3ESK_LCD user logic slave registers.
 *
 * @param   BaseAddress is the base address of the S3ESK_LCD device.
 * @param   Value is the data written to the register.
 *
 * @return  Data is the data from the user logic slave register.
 *
 * @note    None.
 *
 * C-style signature:
 * 	Xuint32 S3ESK_LCD_mReadSlaveRegn(Xuint32 BaseAddress)
 *
 */
#define S3ESK_LCD_mWriteSlaveReg0(BaseAddress, Value) \
 	XIo_Out32((BaseAddress) + (S3ESK_LCD_SLAVE_REG0_OFFSET), (Xuint32)(Value))
#define S3ESK_LCD_mWriteSlaveReg1(BaseAddress, Value) \
 	XIo_Out32((BaseAddress) + (S3ESK_LCD_SLAVE_REG1_OFFSET), (Xuint32)(Value))

#define S3ESK_LCD_mReadSlaveReg0(BaseAddress) \
 	XIo_In32((BaseAddress) + (S3ESK_LCD_SLAVE_REG0_OFFSET))
#define S3ESK_LCD_mReadSlaveReg1(BaseAddress) \
 	XIo_In32((BaseAddress) + (S3ESK_LCD_SLAVE_REG1_OFFSET))

/**
 *
 * Reset S3ESK_LCD via software.
 *
 * @param   BaseAddress is the base address of the S3ESK_LCD device.
 *
 * @return  None.
 *
 * @note    None.
 *
 * C-style signature:
 * 	void S3ESK_LCD_mReset(Xuint32 BaseAddress)
 *
 */
#define S3ESK_LCD_mReset(BaseAddress) \
 	XIo_Out32((BaseAddress)+(S3ESK_LCD_RST_OFFSET), IPIF_RESET)

/**
 *
 * Read module identification information from S3ESK_LCD device.
 *
 * @param   BaseAddress is the base address of the S3ESK_LCD device.
 *
 * @return  None.
 *
 * @note    None.
 *
 * C-style signature:
 * 	Xuint32 S3ESK_LCD_mReadMIR(Xuint32 BaseAddress)
 *
 */
#define S3ESK_LCD_mReadMIR(BaseAddress) \
 	XIo_In32((BaseAddress)+(S3ESK_LCD_MIR_OFFSET))

/************************** Function Prototypes ****************************/


/**
 *
 * Enable all possible interrupts from S3ESK_LCD device.
 *
 * @param   baseaddr_p is the base address of the S3ESK_LCD device.
 *
 * @return  None.
 *
 * @note    None.
 *
 */
void S3ESK_LCD_EnableInterrupt(void * baseaddr_p);

/**
 *
 * Example interrupt controller handler.
 *
 * @param   baseaddr_p is the base address of the S3ESK_LCD device.
 *
 * @return  None.
 *
 * @note    None.
 *
 */
void S3ESK_LCD_Intr_DefaultHandler(void * baseaddr_p);

/**
 *
 * Run a self-test on the driver/device. Note this may be a destructive test if
 * resets of the device are performed.
 *
 * If the hardware system is not built correctly, this function may never
 * return to the caller.
 *
 * @param   baseaddr_p is the base address of the S3ESK_LCD instance to be worked on.
 *
 * @return
 *
 *    - XST_SUCCESS   if all self-test code passed
 *    - XST_FAILURE   if any self-test code failed
 *
 * @note    Caching must be turned off for this function to work.
 * @note    Self test may fail if data memory and device are not on the same bus.
 *
 */
XStatus S3ESK_LCD_SelfTest(void * baseaddr_p);

#endif // S3ESK_LCD_H
